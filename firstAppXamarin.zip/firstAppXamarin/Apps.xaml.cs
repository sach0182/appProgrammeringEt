﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace firstAppXamarin
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Apps : ContentPage
    {
        public Apps()
        {
            InitializeComponent();
            myApp.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.myapptwo.jpg");
            myApp2.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.myapp.jpg");
            myApp3.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.myappthree.jpg");
        }
    }
}