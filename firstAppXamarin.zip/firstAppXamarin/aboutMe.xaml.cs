﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace firstAppXamarin.page
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class aboutMe : ContentPage
    {
        public aboutMe()
        {
            InitializeComponent();
            videMere.Source = ImageSource.FromResource("firstAppXamarin.img.vilDuVideMere.jpg");
        }
    }
}