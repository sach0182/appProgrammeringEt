﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace firstAppXamarin
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            bunnyTwo.Source = ImageSource.FromResource("firstAppXamarin.img.bunnyTwo.png");
        }

        private async void aboutBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new page.aboutMe());
        }


        private async void ContactBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Contact());
        }

        private async void projekterBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Projects());
        }
    }
}
