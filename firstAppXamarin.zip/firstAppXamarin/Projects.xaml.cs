﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace firstAppXamarin
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Projects: ContentPage
    {
        public Projects()
        {
            InitializeComponent();
            galOne.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.app.png");
            galTwo.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.hjemmeside.png");
            galThree.Source = ImageSource.FromResource("firstAppXamarin.img.galleryImg.onlineGame.png");
        }

        private async void appsBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Apps());
        }

        private async void hjemmesiderBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Hjemmesider());
        }

        private async void spilBtn_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new games());
        }
    }
}