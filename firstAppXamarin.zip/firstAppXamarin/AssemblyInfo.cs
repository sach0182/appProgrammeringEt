using Xamarin.Forms.Xaml;
using Xamarin.Forms;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("NerkoOne-Regular.ttf", Alias = "NerkoOne")]
